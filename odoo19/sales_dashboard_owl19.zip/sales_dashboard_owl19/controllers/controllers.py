from odoo import http
from odoo.http import request
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

class SalesDashboard(http.Controller):
    @http.route('/sales_dashboard/statistics',type='json',auth='user')
    def get_sales_statistics(self):
        print (f'in get_sales_statistics')
        draft_orders = request.env['sale.order'].sudo().search([('state','=','draft')])
        confirmed_orders = request.env['sale.order'].sudo().search([('state','=','sale')])
        canceled_orders = request.env['sale.order'].sudo().search([('state','=','cancel')])

        # Get monthly trends data
        monthly_data = self._get_monthly_trends()

        return {
            'draft_orders':len(draft_orders),
            'total_draft_orders':sum(draft_orders.mapped('amount_total')) if draft_orders else 0.0 ,
            'confirmed_orders':len(confirmed_orders),
            'total_confirmed_orders':sum(confirmed_orders.mapped('amount_total')) if confirmed_orders else 0.0 ,
            'canceled_orders':len(canceled_orders),
            'total_canceled_orders':sum(canceled_orders.mapped('amount_total')) if canceled_orders else 0.0,
            # Monthly trends data
            'monthly_labels': monthly_data['labels'],
            'monthly_draft_count': monthly_data['draft_count'],
            'monthly_draft_amount': monthly_data['draft_amount'],
            'monthly_confirmed_count': monthly_data['confirmed_count'],
            'monthly_confirmed_amount': monthly_data['confirmed_amount'],
            'monthly_cancelled_count': monthly_data['cancelled_count'],
            'monthly_cancelled_amount': monthly_data['cancelled_amount'],
        }

    def _get_monthly_trends(self):
        """Get sales order trends for the last 12 months"""
        # Calculate date range (last 12 months)
        end_date = datetime.now()
        start_date = end_date - relativedelta(months=11)

        # Initialize data structures
        labels = []
        draft_count = []
        draft_amount = []
        confirmed_count = []
        confirmed_amount = []
        cancelled_count = []
        cancelled_amount = []

        # Loop through each of the last 12 months
        for i in range(12):
            month_date = start_date + relativedelta(months=i)
            month_start = month_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            month_end = (month_start + relativedelta(months=1)) - timedelta(seconds=1)

            # Format label (e.g., "Nov 2024")
            labels.append(month_date.strftime('%b %Y'))

            # Query draft orders for this month
            draft_orders = request.env['sale.order'].sudo().search([
                ('state', '=', 'draft'),
                ('date_order', '>=', month_start),
                ('date_order', '<=', month_end)
            ])
            draft_count.append(len(draft_orders))
            draft_amount.append(sum(draft_orders.mapped('amount_total')) if draft_orders else 0.0)

            # Query confirmed orders for this month
            confirmed_orders = request.env['sale.order'].sudo().search([
                ('state', '=', 'sale'),
                ('date_order', '>=', month_start),
                ('date_order', '<=', month_end)
            ])
            confirmed_count.append(len(confirmed_orders))
            confirmed_amount.append(sum(confirmed_orders.mapped('amount_total')) if confirmed_orders else 0.0)

            # Query cancelled orders for this month
            cancelled_orders = request.env['sale.order'].sudo().search([
                ('state', '=', 'cancel'),
                ('date_order', '>=', month_start),
                ('date_order', '<=', month_end)
            ])
            cancelled_count.append(len(cancelled_orders))
            cancelled_amount.append(sum(cancelled_orders.mapped('amount_total')) if cancelled_orders else 0.0)

        return {
            'labels': labels,
            'draft_count': draft_count,
            'draft_amount': draft_amount,
            'confirmed_count': confirmed_count,
            'confirmed_amount': confirmed_amount,
            'cancelled_count': cancelled_count,
            'cancelled_amount': cancelled_amount,
        }