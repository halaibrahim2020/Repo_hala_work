# from odoo import models, fields, api


# class sales_dashboard_owl19(models.Model):
#     _name = 'sales_dashboard_owl19.sales_dashboard_owl19'
#     _description = 'sales_dashboard_owl19.sales_dashboard_owl19'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100

