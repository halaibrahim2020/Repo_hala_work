# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

**Sales Dashboard OWL 19** - An Odoo 19 custom module providing a sales analytics dashboard built with the OWL (Odoo Web Library) framework.

- **Odoo Version:** 19.0
- **Module Name:** `sales_dashboard_owl19`
- **Dependencies:** `base`, `sale_management`
- **Primary Features:**
  - Real-time sales order statistics (Draft, Confirmed, Cancelled)
  - Interactive dashboard with clickable metrics
  - Chart.js visualizations (Pie Chart, Area Chart)
  - Quick navigation to filtered order views

## Architecture

### Backend Architecture

**Controller Pattern:**
- Single HTTP controller (`controllers/controllers.py`) with JSON-RPC endpoint
- Route: `/sales_dashboard/statistics` (type: `json`, auth: `user`)
- Returns aggregated statistics from `sale.order` model
- Uses `sudo()` for cross-company data access

**Data Structure:**
```python
{
    'draft_orders': int,           # Count of draft/sent orders
    'total_draft_orders': float,   # Sum of amounts
    'confirmed_orders': int,        # Count of confirmed sales
    'total_confirmed_orders': float,
    'canceled_orders': int,         # Count of cancelled orders
    'total_canceled_orders': float
}
```

### Frontend Architecture

**OWL Component Structure:**

1. **Main Component:** `SalesDashboard` (`static/src/components/dashboard/js/dashboard.js`)
   - Root component registered as action `sales_dashboard_owl19.dashboard`
   - Uses Odoo's Layout component for standard UI frame
   - Manages state with reactive `useState`
   - Integrates three sub-components: `DashboardItem`, `PieChart`, `AreaChart`

2. **Data Service:** `load_data_service` (`static/src/components/dashboard/js/loadDataService.js`)
   - Registered in Odoo's service registry
   - Fetches data from `/sales_dashboard/statistics` on startup
   - Data is injected into component state via `useService("load_data_service")`

3. **Dashboard Items:** `DashboardItem` (`static/src/components/dashboard/js/dashboardItem.js`)
   - Reusable card component for metric display
   - Accepts `size` prop for responsive layout
   - Uses slot pattern for content injection

4. **Chart Components:**
   - **PieChart:** Displays order count distribution (Draft/Confirmed/Cancelled)
   - **AreaChart:** Currently has placeholder implementation (commented code)
   - Both use Chart.js library loaded via `loadJS("/web/static/lib/Chart/Chart.js")`
   - Canvas rendering with `useRef` and lifecycle hooks

**Component Lifecycle:**
```javascript
setup() → useService loads data → onWillStart (load Chart.js) → onMounted (render charts)
```

**Action Navigation:**
- Dashboard buttons trigger `action.doAction()` to open filtered sale.order views
- Three navigation actions: Draft Orders, Confirmed Orders, Cancelled Orders
- Uses domain filters to show specific order states

### Asset Loading

Assets are bundled in `web.assets_backend` via manifest:
```python
'assets': {
    'web.assets_backend': [
        'sales_dashboard_owl19/static/src/**/*',  # All JS, XML, SCSS files
    ],
}
```

## Development Commands

### Module Installation/Updates

```bash
# Install module for the first time
python /opt/odoo19/odoo19/odoo-bin -c /path/to/odoo.conf -d database_name -i sales_dashboard_owl19 --stop-after-init

# Update module after Python/XML changes
python /opt/odoo19/odoo19/odoo-bin -c /path/to/odoo.conf -d database_name -u sales_dashboard_owl19 --stop-after-init

# Development mode with auto-reload for JS/SCSS changes (no restart needed for frontend)
python /opt/odoo19/odoo19/odoo-bin -c /path/to/odoo.conf -d database_name --dev all
```

### Running Odoo Server

```bash
# Standard server start
python /opt/odoo19/odoo19/odoo-bin -c /path/to/odoo.conf -d database_name

# With specific addons path
python /opt/odoo19/odoo19/odoo-bin -c /path/to/odoo.conf -d database_name --addons-path=/opt/odoo19/odoo19-custom-addons
```

### Debugging

**Backend debugging:**
```bash
# Check controller route is registered
# Look for: "POST /sales_dashboard/statistics" in server logs on startup

# Test controller directly
curl -X POST http://localhost:8069/sales_dashboard/statistics \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"call","params":{},"id":1}'
```

**Frontend debugging:**
- Open browser console (F12) to see service logs: "Result from Sales services..."
- Check Network tab for RPC calls to `/sales_dashboard/statistics`
- Use Odoo debug mode: Add `?debug=1` to URL
- Clear browser cache after asset changes if `--dev all` isn't used

## Odoo 19 Specific Patterns

### OWL Components (Odoo 19)

**Component Registration:**
```javascript
import { Component } from "@odoo/owl";
import { registry } from "@web/core/registry";

class MyComponent extends Component {
    static template = "module_name.TemplateName";
}

// Register as client action
registry.category("actions").add("module_name.action_tag", MyComponent);

// Register as service
registry.category("services").add("my_service", serviceObject);
```

**Service Pattern:**
```javascript
const myService = {
    async start(env) {
        // Initialization logic
        return result; // Returned value injected into component
    }
}
```

**Using Odoo Services:**
```javascript
setup() {
    this.action = useService("action");  // Navigation
    this.rpc = useService("rpc");        // Backend calls (alternative)
    this.orm = useService("orm");        // ORM operations
}
```

### JSON-RPC Controllers

**Odoo 19 syntax:**
```python
from odoo import http
from odoo.http import request

class MyController(http.Controller):
    @http.route('/my_route', type='json', auth='user')
    def my_method(self):
        # type='json' in Odoo 19 (was type='json' in v18 too, but 'jsonrpc' is also valid)
        data = request.env['model.name'].search([])
        return data.read(['field1', 'field2'])
```

## File Structure

```
sales_dashboard_owl19/
├── __init__.py                                    # Module entry point
├── __manifest__.py                                # Module metadata & assets
├── controllers/
│   ├── __init__.py
│   └── controllers.py                            # JSON-RPC endpoint
├── models/
│   ├── __init__.py
│   └── models.py                                 # Currently empty (no custom models)
├── views/
│   ├── views.xml                                 # Menu & action definitions
│   └── templates.xml                             # Backend templates (if needed)
├── static/src/components/dashboard/
│   ├── js/
│   │   ├── dashboard.js                         # Main dashboard component
│   │   ├── dashboardItem.js                     # Metric card component
│   │   ├── loadDataService.js                   # Data fetching service
│   │   ├── PieChart.js                          # Pie chart component
│   │   └── AreaChart.js                         # Area chart (incomplete)
│   ├── xml/
│   │   ├── dashboard.xml                        # Main dashboard template
│   │   ├── dashboardItem.xml                    # Card template
│   │   ├── PieChart.xml                         # Pie chart template
│   │   └── AreaChart.xml                        # Area chart template
│   └── scss/
│       └── dashboard.scss                        # Dashboard styles (currently minimal)
└── demo/
    └── demo.xml                                  # Demo data

```

## Customization Guide

### Adding New Metrics

1. **Update Controller:**
   ```python
   # controllers/controllers.py
   pending_orders = request.env['sale.order'].sudo().search([('state','=','pending')])
   return {
       # ... existing metrics
       'pending_orders': len(pending_orders),
       'total_pending_orders': sum(pending_orders.mapped('amount_total'))
   }
   ```

2. **Update Template:**
   ```xml
   <!-- static/src/components/dashboard/xml/dashboard.xml -->
   <DashboardItem size="2">
       <t t-set-slot="default">
           <h3 class="item-text">Total Pending Orders</h3>
           <a href="#" class="order-link" t-on-click.prevent="openPendingOrders">
               <t t-esc="state.statisticas_data.pending_orders"/>
           </a>
       </t>
   </DashboardItem>
   ```

3. **Add Navigation Method:**
   ```javascript
   // static/src/components/dashboard/js/dashboard.js
   async openPendingOrders() {
       await this.action.doAction({
           type: "ir.actions.act_window",
           res_model: "sale.order",
           name: "Pending Sale Orders",
           views: [[false, "list"], [false, "form"]],
           domain: [["state", "=", "pending"]],
       });
   }
   ```

4. **Update Module:**
   ```bash
   python /opt/odoo19/odoo19/odoo-bin -c /path/to/odoo.conf -d database_name -u sales_dashboard_owl19 --stop-after-init
   ```

### Styling Dashboard

Edit `static/src/components/dashboard/scss/dashboard.scss` to customize:
- Card colors and gradients
- Typography and spacing
- Hover effects
- Responsive breakpoints

After SCSS changes with `--dev all` running, refresh browser to see changes.

## Common Issues

**Service data not loading:**
- Check browser console for RPC errors
- Verify controller route is accessible (check server logs)
- Ensure user has access rights to `sale.order` model

**Charts not rendering:**
- Verify Chart.js library path: `/web/static/lib/Chart/Chart.js`
- Check canvas ref is correctly bound: `useRef("chart")`
- Ensure `onMounted` hook executes after data is available
- Check Chart.js color format: use `#36A2EB` not `36A2EB`

**Changes not reflecting:**
- Backend (Python) changes: Restart server or use `-u module_name`
- Frontend (JS/SCSS) without `--dev all`: Clear browser cache and restart Odoo
- Frontend with `--dev all`: Just refresh browser
- XML templates: Update module with `-u` flag

**Action navigation not working:**
- Verify action tags match registered components
- Check domain filter syntax: `[["field", "operator", "value"]]`
- Ensure user has menu access rights (check `groups` attribute in views)

## Menu Access

Navigate to: **Sales Dashboard → Dashboard**

The menu is visible to all users in `base.group_user` group.