/** @odoo-module **/

import { Component, onWillStart, onMounted, useRef } from "@odoo/owl";
import { loadJS } from "@web/core/assets";
import { useService } from "@web/core/utils/hooks";

export class PieChart extends Component {
    static template = "sales_dashboard_owl19.PieChart";

    setup() {
        this.canvasRef = useRef("chart");
        this.chartData = useService("load_data_service");

        onWillStart(async () => {
            await loadJS("/web/static/lib/Chart/Chart.js");
        });

        onMounted(() => {
            const ctx = this.canvasRef.el.getContext("2d");
            const chart = new Chart(ctx, {
                type: "pie",
                data: {
                    labels: ["Draft Orders", "Confirmed Orders", "Cancelled Orders"],
                    datasets: [
                        {
                            data: [
                                this.chartData.draft_orders || 0,
                                this.chartData.confirmed_orders || 0,
                                this.chartData.canceled_orders || 0,
                            ],
                            backgroundColor: [
                                "rgba(79, 70, 229, 0.85)",   // Vibrant Indigo
                                "rgba(16, 185, 129, 0.85)",   // Vibrant Green
                                "rgba(239, 68, 68, 0.85)",   // Vibrant Red
                            ],
                            borderColor: [
                                "rgba(79, 70, 229, 1)",
                                "rgba(16, 185, 129, 1)",
                                "rgba(239, 68, 68, 1)",
                            ],
                            borderWidth: 3,
                            hoverOffset: 15,
                            hoverBorderWidth: 4,
                            hoverBackgroundColor: [
                                "rgba(79, 70, 229, 1)",
                                "rgba(16, 185, 129, 1)",
                                "rgba(239, 68, 68, 1)",
                            ],
                        },
                    ],
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            position: "bottom",
                            labels: {
                                color: "#475569",
                                font: { size: 14, weight: "600", family: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" },
                                padding: 20,
                                usePointStyle: true,
                                pointStyle: "circle",
                            },
                        },
                        title: {
                            display: true,
                            text: "Orders Distribution",
                            font: { size: 18, weight: "bold", family: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" },
                            color: "#1E293B",
                            padding: { top: 10, bottom: 20 },
                        },
                        tooltip: {
                            backgroundColor: "rgba(15, 23, 42, 0.95)",
                            titleColor: "#fff",
                            bodyColor: "#fff",
                            titleFont: { size: 14, weight: "bold" },
                            bodyFont: { size: 13 },
                            padding: 12,
                            cornerRadius: 8,
                            displayColors: true,
                            borderColor: "rgba(255, 255, 255, 0.1)",
                            borderWidth: 1,
                        },
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true,
                        duration: 1000,
                        easing: "easeOutQuart",
                    },
                },
            });
            this.chart = chart;
        });
    }
}
