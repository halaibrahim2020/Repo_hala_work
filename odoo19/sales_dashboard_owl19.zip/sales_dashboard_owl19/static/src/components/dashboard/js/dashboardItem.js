/** @odoo-module **/
import { Component } from "@odoo/owl";

export class DashboardItem extends Component{
    static template = "sales_dashboard_owl19.DashboardItem";

}