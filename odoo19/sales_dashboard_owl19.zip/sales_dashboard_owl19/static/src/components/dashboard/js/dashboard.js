/** @odoo-module **/
import { Component, onMounted, onWillStart, useState } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { Layout } from "@web/search/layout";
import {useService} from "@web/core/utils/hooks";
import {DashboardItem} from "./dashboardItem";
import {PieChart} from "./PieChart";
import {BarChart} from "./BarChart";
import {LineChart} from "./LineChart";


class SalesDashboard extends Component{
    static components = {Layout,DashboardItem,PieChart, BarChart: BarChart,LineChart};
    setup(){
         this.display = {
            controlPanel: {},
        };
         this.action = useService("action");
         this.state = useState({statisticas_data:{},});
         this.state.statisticas_data = useService("load_data_service");

    }
    async openDraftOrders(){
        // await this.action.doAction("sale.action_quotations_with_onboarding");
         await this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "sale.order",
            name: "Draft Sale Orders",
            views: [[false, "list"], [false, "form"]],
            domain: [["state", "in", ["draft","sent"]]],
      });
    };
    async openConfirmedSaleOrders(){
        await this.action.doAction("sale.action_orders");
    }
    async openCancelSaleOrders(){
        await this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "sale.order",
            name: "Cancelled Sale Orders",
            views: [[false, "list"], [false, "form"]],
            domain: [["state", "in", ["cancel"]]],
      });

    }
    static template="sales_dashboard_owl19.SalesDashboard"
}

registry.category("actions").add("sales_dashboard_owl19.dashboard", SalesDashboard);
