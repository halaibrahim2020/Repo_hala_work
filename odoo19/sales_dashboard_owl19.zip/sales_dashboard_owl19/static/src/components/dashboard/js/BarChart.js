/** @odoo-module **/

import { Component, onWillStart, onMounted, useRef } from "@odoo/owl";
import { loadJS } from "@web/core/assets";
import { useService } from "@web/core/utils/hooks";

export class BarChart extends Component{
    static template = "sales_dashboard_owl19.AreaChart";
    setup(){
        this.action = useService("action");
        this.canvasRef= useRef("barChart");
        this.chart = null;
        this.chartData = {
            draft:0,
            confirmed:0,
            cancelled:0
        };
        this.chartData = useService("load_data_service");
        onWillStart(()=>loadJS("/web/static/lib/Chart/Chart.js"));
        onMounted(()=>{
            const ctx = this.canvasRef.el.getContext(("2d"));

            // =========
            this.chart = new Chart(ctx, {
                type: "bar",
                data: {
                    labels: ["Draft Orders", "Confirmed Orders", "Cancelled Orders"],
                    datasets: [
                        {
                            label: "Number of Orders",
                            data: [
                                this.chartData.draft_orders || 0,
                                this.chartData.confirmed_orders || 0,
                                this.chartData.canceled_orders || 0,
                            ],
                            backgroundColor: [
                                "rgba(79, 70, 229, 0.75)",  // Vibrant Indigo
                                "rgba(16, 185, 129, 0.75)",  // Vibrant Green
                                "rgba(239, 68, 68, 0.75)",  // Vibrant Red
                            ],
                            borderColor: [
                                "rgb(79, 70, 229)",
                                "rgb(16, 185, 129)",
                                "rgb(239, 68, 68)",
                            ],
                            borderWidth: 2,
                            borderRadius: 8,
                            hoverBackgroundColor: [
                                "rgba(79, 70, 229, 0.95)",
                                "rgba(16, 185, 129, 0.95)",
                                "rgba(239, 68, 68, 0.95)",
                            ],
                            hoverBorderWidth: 3,
                        },
                    ],
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            position: "top",
                            labels: {
                                color: "#475569",
                                font: { size: 14, weight: "600", family: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" },
                                padding: 15,
                                usePointStyle: false,
                            },
                        },
                        title: {
                            display: true,
                            text: "Orders by Status",
                            font: { size: 18, weight: "bold", family: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" },
                            color: "#1E293B",
                            padding: { top: 10, bottom: 20 },
                        },
                        tooltip: {
                            backgroundColor: "rgba(15, 23, 42, 0.95)",
                            titleColor: "#fff",
                            bodyColor: "#fff",
                            titleFont: { size: 14, weight: "bold" },
                            bodyFont: { size: 13 },
                            padding: 12,
                            cornerRadius: 8,
                            displayColors: true,
                            borderColor: "rgba(255, 255, 255, 0.1)",
                            borderWidth: 1,
                            callbacks: {
                                label: function(context) {
                                    return context.dataset.label + ': ' + context.parsed.y + ' orders';
                                }
                            }
                        },
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0,
                                color: "#64748B",
                                font: { size: 12, weight: "500" },
                            },
                            grid: {
                                color: "rgba(148, 163, 184, 0.15)",
                                borderColor: "#CBD5E1",
                            },
                        },
                        x: {
                            ticks: {
                                color: "#64748B",
                                font: { size: 12, weight: "600" },
                            },
                            grid: {
                                display: false,
                            },
                        },
                    },
                    animation: {
                        duration: 1000,
                        easing: "easeOutQuart",
                    },
                    onClick: (evt, elements) => {
                        if (elements.length > 0) {
                            const index = elements[0].index;
                            const state = ["draft", "sale", "cancel"][index];
                            this.openOrdersByState(state);
                        }
                    },
                },
            });

            // =========

        })
    }

    // Optional helper: open filtered sale orders when clicking bar
    async openOrdersByState(state) {
        const domainMap = {
            draft: [["state", "in", ["draft", "sent"]]],
            sale: [["state", "=", "sale"]],
            cancel: [["state", "=", "cancel"]],
        };
        await this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "sale.order",
            name: `${state.charAt(0).toUpperCase() + state.slice(1)} Sale Orders`,
            views: [[false, "list"], [false, "form"]],
            domain: domainMap[state],
        });
    }
    // ========
}