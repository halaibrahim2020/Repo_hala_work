/** @odoo-module **/

import { Component, onWillStart, onMounted, useRef } from "@odoo/owl";
import { loadJS } from "@web/core/assets";
import { useService } from "@web/core/utils/hooks";

export class LineChart extends Component {
    static template = "sales_dashboard_owl19.LineChart";

    setup() {
        this.canvasRef = useRef("lineChart");
        this.chartData = useService("load_data_service");

        onWillStart(async () => {
            await loadJS("/web/static/lib/Chart/Chart.js");
        });

        onMounted(() => {
            const ctx = this.canvasRef.el.getContext("2d");

            // Get dynamic monthly labels from backend
            const labels = this.chartData.monthly_labels || [];

            new Chart(ctx, {
                type: "line",
                data: {
                    labels,
                    datasets: [
                        {
                            label: "Draft Orders Revenue",
                            data: this.chartData.monthly_draft_amount || [],
                            fill: true,
                            borderColor: "rgba(79, 70, 229, 1)",  // Vibrant Indigo
                            backgroundColor: "rgba(79, 70, 229, 0.1)",
                            borderWidth: 3,
                            tension: 0.4,
                            pointRadius: 4,
                            pointHoverRadius: 6,
                            pointBackgroundColor: "rgba(79, 70, 229, 1)",
                            pointBorderColor: "#fff",
                            pointBorderWidth: 2,
                            pointHoverBackgroundColor: "rgba(79, 70, 229, 1)",
                            pointHoverBorderColor: "#fff",
                            // Store count data for tooltip
                            countData: this.chartData.monthly_draft_count || [],
                        },
                        {
                            label: "Confirmed Orders Revenue",
                            data: this.chartData.monthly_confirmed_amount || [],
                            fill: true,
                            borderColor: "rgba(16, 185, 129, 1)",  // Vibrant Green
                            backgroundColor: "rgba(16, 185, 129, 0.1)",
                            borderWidth: 3,
                            tension: 0.4,
                            pointRadius: 4,
                            pointHoverRadius: 6,
                            pointBackgroundColor: "rgba(16, 185, 129, 1)",
                            pointBorderColor: "#fff",
                            pointBorderWidth: 2,
                            pointHoverBackgroundColor: "rgba(16, 185, 129, 1)",
                            pointHoverBorderColor: "#fff",
                            countData: this.chartData.monthly_confirmed_count || [],
                        },
                        {
                            label: "Cancelled Orders Revenue",
                            data: this.chartData.monthly_cancelled_amount || [],
                            fill: true,
                            borderColor: "rgba(239, 68, 68, 1)",  // Vibrant Red
                            backgroundColor: "rgba(239, 68, 68, 0.1)",
                            borderWidth: 3,
                            tension: 0.4,
                            pointRadius: 4,
                            pointHoverRadius: 6,
                            pointBackgroundColor: "rgba(239, 68, 68, 1)",
                            pointBorderColor: "#fff",
                            pointBorderWidth: 2,
                            pointHoverBackgroundColor: "rgba(239, 68, 68, 1)",
                            pointHoverBorderColor: "#fff",
                            countData: this.chartData.monthly_cancelled_count || [],
                        },
                    ],
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    aspectRatio: 3,
                    interaction: {
                        mode: 'index',
                        intersect: false,
                    },
                    plugins: {
                        legend: {
                            position: "bottom",
                            labels: {
                                usePointStyle: true,
                                pointStyle: 'circle',
                                color: "#475569",
                                font: { size: 14, weight: "600", family: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" },
                                padding: 20,
                            },
                        },
                        title: {
                            display: true,
                            text: "Sales Trends - Last 12 Months",
                            color: "#1E293B",
                            font: { size: 18, weight: "bold", family: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" },
                            padding: { top: 10, bottom: 20 },
                        },
                        tooltip: {
                            backgroundColor: "rgba(15, 23, 42, 0.95)",
                            titleColor: "#fff",
                            bodyColor: "#fff",
                            titleFont: { size: 14, weight: "bold" },
                            bodyFont: { size: 13 },
                            padding: 12,
                            cornerRadius: 8,
                            displayColors: true,
                            borderColor: "rgba(255, 255, 255, 0.1)",
                            borderWidth: 1,
                            callbacks: {
                                label: function(context) {
                                    const datasetLabel = context.dataset.label || '';
                                    const amount = context.parsed.y || 0;
                                    const count = context.dataset.countData[context.dataIndex] || 0;
                                    return `${datasetLabel}: $${amount.toFixed(2)} (${count} orders)`;
                                }
                            }
                        },
                    },
                    scales: {
                        x: {
                            grid: { display: false },
                            ticks: {
                                color: "#64748B",
                                font: { size: 12, weight: "500" },
                            },
                        },
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: "rgba(148, 163, 184, 0.15)",
                                borderColor: "#CBD5E1",
                            },
                            ticks: {
                                color: "#64748B",
                                font: { size: 12, weight: "500" },
                                callback: function(value) {
                                    return '$' + value.toFixed(0);
                                }
                            },
                        },
                    },
                    animation: {
                        duration: 1000,
                        easing: "easeOutQuart",
                    },
                },
            });
        });
    }
}
