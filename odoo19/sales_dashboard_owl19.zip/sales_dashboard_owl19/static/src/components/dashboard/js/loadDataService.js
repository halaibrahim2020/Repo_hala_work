import { registry } from "@web/core/registry";
import { rpc } from "@web/core/network/rpc";


const loadDataService = {
    async start(env){
        try{
            const result = await rpc("/sales_dashboard/statistics")
            if (!result.error){
                console.log("Result from Sales services...",result)
                return result
            }
        }
        catch(e){
            console.error("Fetch Error while loading sales Data",e)
        }
    }
}
registry.category("services").add("load_data_service", loadDataService);